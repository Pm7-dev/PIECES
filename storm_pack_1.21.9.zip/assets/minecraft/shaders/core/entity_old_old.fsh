#version 150

#moj_import <minecraft:fog.glsl>

uniform sampler2D Sampler0;

uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform vec4 FogColor;

in float vertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;

// Position relative to the player, unused
in vec3 relativeCoords;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    ivec4 colorRGB = ivec4(int(floor(color.x * 255)), int(floor(color.y * 255)), int(floor(color.z * 255)), int(floor(color.w * 255)));

    // Taste the rainbow
    if(colorRGB == ivec4(255, 42, 0, 255)) {
        fragColor = vec4(255, 51, 51, 255)/255;
        return;
    } else 
    if(colorRGB == ivec4(255, 84, 0, 255)) {
        fragColor = vec4(255, 119, 51, 255)/255;
        return;
    } else 
    if(colorRGB == ivec4(255, 127, 0, 255)) {
        fragColor = vec4(255, 255, 51, 255)/255;
        return;
    } else 
    if(colorRGB == ivec4(255, 170, 0, 255)) {
        fragColor = vec4(51, 255, 51, 255)/255;
        return;
    } else 
    if(colorRGB == ivec4(255, 212, 0, 255)) {
        fragColor = vec4(51, 248, 255, 255)/255;
        return;
    } else 
    if(colorRGB == ivec4(170, 255, 0, 255)) {
        fragColor = vec4(235, 51, 255, 255)/255;
        return;
    } else 
    if(colorRGB == ivec4(127, 255, 0, 255)) {
        fragColor = vec4(51, 160, 255, 255)/255;
        return;
    } else 
    if(colorRGB == ivec4(84, 255, 0, 255)) {
        fragColor = vec4(51, 255, 167, 255)/255;
        return;
    } else 

    // These were submitted by piffin fans
    if(colorRGB == ivec4(42, 255, 0, 255)) {
        fragColor = vec4(255, 71, 169, 255)/255; // LizardLyd rgb(255, 71, 169)
        return;
    } else 
    if(colorRGB == ivec4(0, 255, 0, 255)) {
        fragColor = vec4(235, 97, 35, 255)/255; // Trap rgb(235, 97, 35)
        return;
    } else 
    if(colorRGB == ivec4(0, 255, 42, 255)) {
        fragColor = vec4(194, 120, 255, 255)/255; // d<3 rgb(194, 120, 255)
        return;
    } else 
    if(colorRGB == ivec4(0, 255, 84, 255)) {
        fragColor = vec4(132, 37, 147, 255)/255; // Dedede rgb(132, 37, 147)
        return;
    } else 
    if(colorRGB == ivec4(0, 255, 127, 255)) {
        fragColor = vec4(7, 70, 133, 255)/255; // ATV rgb(7, 70, 133)
        return;
    } else 
    if(colorRGB == ivec4(0, 255, 212, 255)) {
        fragColor = vec4(255, 136, 26, 255)/255; // Magma rgb(255, 136, 26)
        return;
    } else 
    if(colorRGB == ivec4(0, 255, 255, 255)) {
        fragColor = vec4(66, 200, 245, 255)/255; // millionbucks1 rgb(66, 200, 245)
        return;
    } else 
    if(colorRGB == ivec4(0, 212, 255, 255)) {
        fragColor = vec4(30, 129, 176, 255)/255; // Enter Name Here (I swear this was intentional) rgb(30, 129, 176)
        return;
    } else
    if(colorRGB == ivec4(0, 170, 255, 255)) {
        fragColor = vec4(49, 97, 36, 255)/255; // Oliver rgb(49, 97, 36)
        return;
    }

#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif
    color *= vertexColor * ColorModulator;
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    color *= lightMapColor;
#endif
    fragColor = linear_fog(color, vertexDistance, FogStart, FogEnd, FogColor);
}
